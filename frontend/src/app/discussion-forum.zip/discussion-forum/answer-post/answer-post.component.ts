import { Component, EventEmitter, Output } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-answer-post',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './answer-post.component.html',
  styleUrl: './answer-post.component.css'
})
export class AnswerPostComponent {
  @Output() answerPosted = new EventEmitter<string>();
  answerText: string = '';

  postAnswer() {
    if (this.answerText.trim() !== '') {
      this.answerPosted.emit(this.answerText);
      this.answerText = '';
    }
  }
}
