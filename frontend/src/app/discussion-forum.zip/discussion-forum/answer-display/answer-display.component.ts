import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-answer-display',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './answer-display.component.html',
  styleUrl: './answer-display.component.css'
})
export class AnswerDisplayComponent {
  @Input()
  answer!: string;
}
