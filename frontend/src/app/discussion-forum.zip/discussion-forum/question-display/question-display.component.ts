import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-question-display',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './question-display.component.html',
  styleUrl: './question-display.component.css'
})
export class QuestionDisplayComponent {
  @Input()
  question!: { user: string; timestamp: Date; title: string; content: string; };
}
