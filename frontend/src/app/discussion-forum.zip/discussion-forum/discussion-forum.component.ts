import { Component } from '@angular/core';
import { AnswerDisplayComponent } from "./answer-display/answer-display.component";
import { HeadPartComponent } from "./head-part/head-part.component";
import { QuestionDisplayComponent } from "./question-display/question-display.component";
import { AnswerPostComponent } from './answer-post/answer-post.component';
@Component({
    selector: 'app-discussion-forum',
    standalone: true,
    templateUrl: './discussion-forum.component.html',
    styleUrl: './discussion-forum.component.css',
    imports: [AnswerDisplayComponent, HeadPartComponent, QuestionDisplayComponent, AnswerPostComponent]
})
export class DiscussionForumComponent {
    question = {
        user: 'John Doe',
        timestamp: new Date(),
        title: 'Sample Question',
        content: 'This is a sample question.'
      };
    answers = ['Try this solution...', 'Another possible solution...'];
    postAnswer(answer: string) {
        this.answers.push(answer);
    }
}
