import { Component } from '@angular/core';

@Component({
    selector: 'app-head-part',
    standalone: true,
    templateUrl: './head-part.component.html',
    styleUrl: './head-part.component.css',
    imports: []
})
export class HeadPartComponent {

  showBox = false; // Flag to control box display

  toggleBox() {
    this.showBox = !this.showBox;
  }

}
